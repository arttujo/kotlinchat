//Arttu Jokinen
//1606267
//Main program.
fun main(args:Array<String>){
    ChatServer().serve()
}